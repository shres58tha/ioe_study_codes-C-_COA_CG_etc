#include <iostream>
#include <string>
using namespace std;


main{
	// code here

return 0;
}
