#include <iostream>
#include "human.h" 
using namespace std;

int main(){
    Human person;
    person.input_data();
    cout <<endl;
    person.show_data();
return 0;    
}
