// useage : input_ ( string to be desplayed for prompt, pointer to data to be saved)
// input_ overloaded
// failed to put it in another file as not sure how to declare template class in h file
#ifndef MY_INPUT_H // include guard
#define MY_INPUT_H

#include<iostream>
#include <string>   //for string

using namespace std;
template< class T>
void input_( string str, T *p){  // get input  with error checking
        int error;
        do {                  
            error=0;
            if (cin.fail()){ cin.clear();  cin.ignore(100000000,'\n');}
            cout << str;
            cin>>*p;   
            if (cin.peek()!='\n') {cin.ignore(100000000,'\n');error=1;}
            else cin.ignore();
        }while(cin.fail()||error );
}
void input_( string str, string *p){  // input string to string pointer  // template overloaded
        do{
            if (cin.fail()){cin.clear(); while (cin.ignore(100000000,'\n'));}
            cout << str ;      // prompt 
            getline(cin,*p);   // does not leave dangling anything in the input stream
        }while(cin.fail() || p->empty());
}

void input_( bool *p){   // template overloaded
        char ch;
        int bad_input;
        do {           // get input  with error checking
            bad_input=0;
            if (cin.fail()){ cin.clear();  cin.ignore(100000000,'\n');}
            cout << "Enter 'y' for true and 'n' for false : ";
            cin>>ch;    
            ch =tolower(ch);                                     
            if ( cin.peek() != '\n' )
               { cin.ignore(100000, '\n');  bad_input=1;}  
            else 
                cin.ignore();// remove the '/n' from in stream for the next scanning
            if (ch == 'y') *p=1;
            else if (ch == 'n') *p=0;
            else bad_input=1;
            
        }while(bad_input);
}
#endif /* MY_NOTE_H */
