 
// global data structures
#ifndef GLOBAL_H        // include guard
#define GLOBAL_H
#include "input_.h"
#include <iostream>
#include <string>
#include <vector>

using namespace std;
class xyz{
    int sz, it;
    int arr[10];
public:
    xyz(int a=0):sz(a),it(0){
        cout<<"constructor"<<endl;
    }
    void set_it (int x){it=x;}
    int get(){return arr[it];}
    void set(int x){arr[it]=x;}
  
};



    
class string_array{     // create array as string_array name( size of array);
    //vector can be used but is unnecessary and will take more cpu cycles than this
private:
     int sz;       // size
     int it;    // iterator
     std::string *str;   // can be declared vector <string> str, then we can use push pop too initialize and modify following classes accordingly
    
public:
    string_array(  int size=1):sz(size),it(0){
        str = new  std::string[sz+1];       //+1 for mem guard as last pointer cant be pointed ?? why
                                            // making string array by dynamic allocation
    }
    ~string_array(){                        //destructot 
        delete  []str;
    }
    
    void start() { it=0;    }               // reset iterator  to start
    void end()   { it=sz-1; }               // set iterator to end
    bool valid() {
        if (it >= 0 && it < sz){ return 1; } // 1 = true  = successful
        else { return 0; }   
    }
    int iterator () {return it; }; // returns value of current iterator
    bool next()  {
        if (it >= 0 && it < sz){ it++; return 1; } // 1 = true  = successful
        else { return 0; }   
    }
    bool set_it ( int i){           // sets the iterator to value i
        if (i >= 0 && i < sz){ it=i; return 1; } // 1 = true  = successful
        else { return 0; }                       // 0 = false = failure
    }

    
    void set (std::string s){ str[it]=s;}       //set the string []
    std::string get (){ return str[it];}
    
    // set iterator to start if want to set all the elements
    bool set_next(string s){                    // set the string and point to next location
        if (it >= 0 && it < sz){
            str[it]=s; 
            it++; 
            return 1;   //successful
        }
        else{
            return 0;   //not successful
        }
    }
    
    // set iterator to start if want to get all the elements
    std::string get_next(){               
        if (it >= 0 && it < sz) {   
            return str[it];  //successful
             it++; 
        }
        else{
            return 0;   //not successful
        }
    }
};

class contact_ {
public:
            string name;
            int number;
            vector <string> address;
            vector <string> email;            
    };

#endif //GLOBAL_H
