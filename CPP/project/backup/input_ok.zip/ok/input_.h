// input soutce code
#ifndef MY_INPUT_H // include guard
#define MY_INPUT_H


#include<iostream>
#include <string>   //for string
#include <iomanip>  //for setw()

using namespace std;
// global functions
void input_( string str, string *p);
void input_( string str, int *p);
void input_( string str, float *p);
void input_( string str, double *p);
void input_( string str, bool *p);
void input_yn_( bool *p);


#endif /* MY_NOTE_H */
