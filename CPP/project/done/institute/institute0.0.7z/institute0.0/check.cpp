#include <iostream>
#include "institute.h" 
using namespace std;

int main(){
    institute college;
    college.input_data();
    cout <<endl;
    college.show_data();
return 0;    
}
