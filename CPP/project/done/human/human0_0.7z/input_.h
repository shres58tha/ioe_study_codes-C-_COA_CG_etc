// useage : input_ ( string to be desplayed for prompt, pointer to data to be saved)
// input_ overloaded
// failed to put it in another file as not sure how to declare template class in h file
// global functions

#ifndef MY_INPUT_H // include guard
#define MY_INPUT_H

#include <iostream>
#include <string>   //for string
using namespace std;

template< class T>
void input_( string str, T *p){  // get input  with error checking
        int error;
        do {                  
            error=0;
            if (cin.fail()){ cin.clear();  cin.ignore(100000000,'\n');}
            cout << str;
            cin>>*p;   
            if (cin.peek()!='\n') {cin.ignore(100000000,'\n');error=1;}
            else cin.ignore();
        }while(cin.fail()||error );
}
void input_( string str, string *p);

void input_( bool *p);

#endif /* MY_INPUT_H */
